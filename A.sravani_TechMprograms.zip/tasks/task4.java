package tasks;
import java.util.*;
public class task4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int[] a= {1,2,3,4,5,6,7};
     int b[]= Arrays.copyOfRange(a, 0, 3);
    for(int i:b)
    	System.out.print(i+" ");
	}

}
